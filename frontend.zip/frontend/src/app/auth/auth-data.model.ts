export interface AuthData {
    name: any;
    email: string;
    password: string;
  }