import { Component, OnInit } from '@angular/core';

import { AuthService } from './../auth/auth.service';
import{ Router } from '@angular/router'
import { NgForm } from '@angular/forms';
//import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(public authService : AuthService, private route:Router) { }

  ngOnInit(): void {
  }
  onLogin(form:  NgForm){
    if(form.invalid){
      //this.sankBar.open("Please enter valid data", 'Close');
      alert("Please enter valid data")
      return;

    }
    //this.sankBar.open("Logging... Please wait ", 'Close');
    alert("Logging... Please wait ")
    this.authService.login(form.value.email,form.value.password);
  };

}
